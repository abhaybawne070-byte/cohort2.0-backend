const mongoose=require("mongoose")

function connectedToDB(){
    mongoose.connect("mongodb+srv://abhaybawne070_db_user:Uqe3mSQwSre2R5Fe@cluster0.gcwsvmk.mongodb.net/Day07")
    .then(()=>{
        console.log("connected to the database")
    })
}

module.exports=connectedToDB